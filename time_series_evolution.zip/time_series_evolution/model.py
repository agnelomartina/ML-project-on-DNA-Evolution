import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import os

from sklearn.preprocessing import StandardScaler, LabelEncoder, MinMaxScaler
from sklearn.cluster import KMeans, DBSCAN
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.feature_selection import SelectKBest, f_classif, chi2

from scipy.cluster.hierarchy import dendrogram, linkage
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.arima.model import ARIMA
from xgboost import XGBClassifier

# Paths--->setting paths for  arima_forecast,dendogram, pca and t-sne
OUTPUT_DIR = "outputs/"
DATA_PATH = "dataset/evolution_time_series_updated.csv"

if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

# Load Data
def load_data():
    df = pd.read_csv(DATA_PATH, parse_dates=["year"])
    df = df.sort_values("year")
    df.set_index("year", inplace=True)
    return df

# Feature Engineering (Time-Series)
def add_time_features(df):

    # Rolling averages
    df["rolling_gc_3"] = df["gc_content"].rolling(3, min_periods=1).mean()
    df["rolling_gc_5"] = df["gc_content"].rolling(5, min_periods=1).mean()
    df["rolling_mutation_3"] = df["mutation_rate"].rolling(3, min_periods=1).mean()

    # Lag features
    df["lag_gc_1"] = df["gc_content"].shift(1)
    df["lag_gc_2"] = df["gc_content"].shift(2)
    df["lag_mutation_1"] = df["mutation_rate"].shift(1)
    df["lag_mutation_2"] = df["mutation_rate"].shift(2)

    df = df.bfill()

    return df

# Preprocessing + Feature Selection
def preprocess(feature_selection="anova", k=8):

    df = load_data()
    df = add_time_features(df)

    y = df["class"]
    label_encoder = LabelEncoder()
    y_encoded = label_encoder.fit_transform(y)

    numeric_cols = df.select_dtypes(include=["int64", "float64"]).columns
    X = df[numeric_cols]

    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    if feature_selection == "anova":
        selector = SelectKBest(f_classif, k=min(k, X.shape[1]))
        X_selected = selector.fit_transform(X_scaled, y_encoded)

    elif feature_selection == "chi2":
        minmax = MinMaxScaler()
        X_nonneg = minmax.fit_transform(X)
        selector = SelectKBest(chi2, k=min(k, X.shape[1]))
        X_selected = selector.fit_transform(X_nonneg, y_encoded)

    else:
        X_selected = X_scaled

    return X_selected, y_encoded, label_encoder

# Time-Aware Train/Test Split
def time_series_split(X, y, test_size=0.25):
    split_index = int(len(X) * (1 - test_size))
    return X[:split_index], X[split_index:], y[:split_index], y[split_index:]

# Unsupervised Learning
def run_kmeans(k=3):
    X, _, _ = preprocess()
    model = KMeans(n_clusters=k, random_state=42)
    return model.fit_predict(X)

def run_dbscan(eps=1.2, min_samples=5):
    X, _, _ = preprocess()
    model = DBSCAN(eps=eps, min_samples=min_samples)
    return model.fit_predict(X)

def run_hierarchical():
    X, _, _ = preprocess()
    linked = linkage(X, method="ward")

    plt.figure(figsize=(10,6))
    dendrogram(linked)
    plt.title("Phylogenetic Tree Approximation")

    path = os.path.join(OUTPUT_DIR, "dendrogram.png")
    plt.savefig(path)
    plt.close()
    return path

# Dimensionality Reduction
def run_pca():
    X, _, _ = preprocess()
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X)

    plt.figure(figsize=(6,5))
    plt.scatter(X_pca[:,0], X_pca[:,1], s=10)
    plt.title("PCA - Time Series DNA")

    path = os.path.join(OUTPUT_DIR, "pca.png")
    plt.savefig(path)
    plt.close()
    return path

def run_tsne(perplexity=30):
    X, _, _ = preprocess()

    n_samples, n_features = X.shape
    n_components = min(50, n_features)

    pca = PCA(n_components=n_components)
    X_pca = pca.fit_transform(X)

    tsne = TSNE(n_components=2,
                perplexity=min(perplexity, n_samples-1),
                random_state=42)

    X_tsne = tsne.fit_transform(X_pca)

    plt.figure(figsize=(6,5))
    plt.scatter(X_tsne[:,0], X_tsne[:,1], s=10)
    plt.title("t-SNE - Time Series DNA")

    path = os.path.join(OUTPUT_DIR, "tsne.png")
    plt.savefig(path)
    plt.close()
    return path

# Model Comparison
def train_test_comparison():

    X, y, _ = preprocess("anova")
    X_train, X_test, y_train, y_test = time_series_split(X, y)

    models = {
        "Random Forest": RandomForestClassifier(),
        "SVM": SVC(),
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "XGBoost": XGBClassifier(eval_metric="mlogloss")
    }

    results = {}

    for name, model_instance in models.items():
        model_instance.fit(X_train, y_train)

        train_acc = accuracy_score(y_train,
                                   model_instance.predict(X_train))
        test_acc = accuracy_score(y_test,
                                  model_instance.predict(X_test))

        results[name] = (round(train_acc*100,2),
                         round(test_acc*100,2))

    return results

# Train All Classifiers
def train_classifiers():

    X, y, label_encoder = preprocess()

    models = {
        "Random Forest": RandomForestClassifier(),
        "SVM": SVC(),
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "XGBoost": XGBClassifier(eval_metric="mlogloss")
    }

    for model_instance in models.values():
        model_instance.fit(X, y)

    return models, label_encoder

# Confusion Matrix
def generate_confusion_matrix():

    X, y, _ = preprocess("anova")
    X_train, X_test, y_train, y_test = time_series_split(X, y)

    model_rf = RandomForestClassifier()
    model_rf.fit(X_train, y_train)
    y_pred = model_rf.predict(X_test)

    cm = confusion_matrix(y_test, y_pred)

    plt.figure(figsize=(6,5))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues")
    plt.title("Confusion Matrix - RF")

    path = os.path.join(OUTPUT_DIR, "confusion_matrix.png")
    plt.savefig(path)
    plt.close()
    return path

# Time-Series Decomposition
def perform_decomposition(column="mutation_rate"):

    df = load_data()
    series = df[column]

    decomposition = seasonal_decompose(series,
                                       model="additive",
                                       period=5)

    fig = decomposition.plot()
    fig.set_size_inches(8,6)

    path = os.path.join(OUTPUT_DIR, "decomposition.png")
    plt.savefig(path)
    plt.close()
    return path

# ARIMA Forecast
def run_arima_forecast(column="mutation_rate", steps=10):

    df = load_data()
    series = df[column]

    model = ARIMA(series, order=(2,1,2))
    model_fit = model.fit()

    forecast = model_fit.forecast(steps=steps)

    plt.figure(figsize=(8,5))
    plt.plot(series, label="Historical")
    plt.plot(forecast.index, forecast,
             linestyle="--", label="Forecast")
    plt.legend()
    plt.title("ARIMA Forecast")

    path = os.path.join(OUTPUT_DIR, "arima_forecast.png")
    plt.savefig(path)
    plt.close()
    return path

# Live Prediction
def predict_live(feature_values, model_name="Random Forest"):

    models, label_encoder = train_classifiers()

    if model_name not in models:
        model_name = "Random Forest"

    prediction = models[model_name].predict([feature_values])

    return label_encoder.inverse_transform(prediction)[0]