import tkinter as tk
from tkinter import messagebox, Toplevel
from PIL import Image, ImageTk
import model
import os
import webbrowser

# ------------------ Setup ------------------
OUTPUT_DIR = "outputs/"
if not os.path.exists(OUTPUT_DIR):
    os.makedirs(OUTPUT_DIR)

root = tk.Tk()
root.title("DNA Evolution Time-Series Analysis System")
root.geometry("540x780")

# ------------------ Background Image ------------------
bg_image_path = "dna_background.jpg"

if os.path.exists(bg_image_path):
    bg_image = Image.open(bg_image_path)
    bg_image = bg_image.resize((540, 780), Image.Resampling.LANCZOS)
    bg_photo = ImageTk.PhotoImage(bg_image)
    bg_label = tk.Label(root, image=bg_photo)
    bg_label.place(x=0, y=0, relwidth=1, relheight=1)
else:
    root.configure(bg="#e0f7fa")

# ------------------ Main Frame ------------------
frame = tk.Frame(root, bg="#ffffff", bd=2, relief="ridge")
frame.place(relx=0.5, rely=0.5, anchor="center")

# ------------------ Helper ------------------
def show_message(msg):
    messagebox.showinfo("Result", msg)

# ==============================
# Clustering
# ==============================
def run_kmeans_gui():
    labels = model.run_kmeans()
    show_message(f"K-Means clustering completed.\nClusters found: {len(set(labels))}")

def run_dbscan_gui():
    labels = model.run_dbscan()
    show_message(f"DBSCAN clustering completed.\nClusters found: {len(set(labels))}")

def run_dendrogram_gui():
    path = model.run_hierarchical()
    webbrowser.open(os.path.abspath(path))

# ==============================
# Dimensionality Reduction
# ==============================
def run_pca_gui():
    path = model.run_pca()
    webbrowser.open(os.path.abspath(path))

def run_tsne_gui():
    path = model.run_tsne()
    webbrowser.open(os.path.abspath(path))

# ==============================
# Model Training
# ==============================
def show_train_test_accuracy_gui():
    results = model.train_test_comparison()
    text = ""
    for name, acc in results.items():
        text += f"{name}\n  Train: {acc[0]}%\n  Test: {acc[1]}%\n\n"
    show_message(text)

def show_trained_models_gui():
    trained_models, _ = model.train_classifiers()
    show_message("Trained Models:\n\n" + "\n".join(trained_models.keys()))

# ==============================
# Confusion Matrix
# ==============================
def show_confusion_matrix_gui():
    path = model.generate_confusion_matrix()
    webbrowser.open(os.path.abspath(path))

# ==============================
# Time-Series Analysis
# ==============================
def show_decomposition_gui():
    path = model.perform_decomposition()
    webbrowser.open(os.path.abspath(path))

def show_forecast_gui():
    path = model.run_arima_forecast()
    webbrowser.open(os.path.abspath(path))

# ==============================
# Live Prediction
# ==============================
def open_live_prediction_form_gui():

    df = model.load_data()
    df = model.add_time_features(df)

    numeric_features = df.select_dtypes(include=["int64", "float64"]).columns

    trained_models, label_encoder = model.train_classifiers()
    model_names = list(trained_models.keys())

    win = Toplevel(root)
    win.title("Live DNA Prediction")
    win.geometry("450x650")

    entries = {}

    tk.Label(win, text="Enter DNA Features",
             font=("Arial", 14, "bold")).pack(pady=10)

    # Scrollable area
    canvas = tk.Canvas(win)
    scrollbar = tk.Scrollbar(win, orient="vertical", command=canvas.yview)
    scroll_frame = tk.Frame(canvas)

    scroll_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
    )

    canvas.create_window((0, 0), window=scroll_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=1)
    scrollbar.pack(side="right", fill="y")

    for feature in numeric_features:
        frame_f = tk.Frame(scroll_frame)
        frame_f.pack(pady=2)

        tk.Label(frame_f, text=feature, width=18).pack(side="left")
        entry = tk.Entry(frame_f)
        entry.pack(side="right")

        entries[feature] = entry

    tk.Label(win, text="Select Model:",
             font=("Arial", 12, "bold")).pack(pady=10)

    selected_model = tk.StringVar(win)
    selected_model.set(model_names[0])
    tk.OptionMenu(win, selected_model, *model_names).pack(pady=5)

    def predict():
        try:
            values = [float(entries[f].get()) for f in numeric_features]
            pred = model.predict_live(values,
                                      model_name=selected_model.get())
            messagebox.showinfo("Prediction Result",
                                f"Predicted Species Class:\n{pred}")
        except Exception as e:
            messagebox.showerror("Error", f"Invalid input:\n{e}")

    tk.Button(win,
              text="Predict",
              command=predict,
              width=20,
              bg="#b2dfdb").pack(pady=20)

# ==============================
# GUI Layout
# ==============================
tk.Label(frame,
         text="DNA Evolution Analysis System",
         font=("Arial", 16, "bold"),
         bg="#ffffff").pack(pady=10)

button_bg = "#b2dfdb"

tk.Button(frame, text="K-Means Clustering",
          width=45, command=run_kmeans_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="DBSCAN Clustering",
          width=45, command=run_dbscan_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="Phylogenetic Tree (Dendrogram)",
          width=45, command=run_dendrogram_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="PCA Visualization",
          width=45, command=run_pca_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="t-SNE Visualization",
          width=45, command=run_tsne_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="Show Trained ML Models",
          width=45, command=show_trained_models_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="Train/Test Accuracy Comparison",
          width=45, command=show_train_test_accuracy_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="Confusion Matrix (RF Model)",
          width=45, command=show_confusion_matrix_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="Time-Series Decomposition",
          width=45, command=show_decomposition_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="ARIMA Forecast (Mutation Rate)",
          width=45, command=show_forecast_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="Live DNA Feature Prediction",
          width=45, command=open_live_prediction_form_gui,
          bg=button_bg).pack(pady=5)

tk.Button(frame, text="Exit",
          width=45, command=root.quit,
          bg="#ef9a9a").pack(pady=20)

root.mainloop()